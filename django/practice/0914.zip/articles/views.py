from django.shortcuts import render, redirect
from .models import Article
from .forms import ArticleForm


# Create your views here.
def index(request):
    # READ
    # 1. 사용할 모델을 불러온다
    # 2. ORM을 이용해서 DB를 모든 게시글에 가져온다.
    # 3. context에 담아서 템플릿에 넘겨준다
    articles = Article.objects.all()
    context = {
        'articles':articles,
    }
    return render(request, 'articles/index.html', context)


# def new(request):
#     # 게시글 작성 폼이 담신 페이지를 보여준다
#     return render(request, 'articles/new.html')


def create(request):

    if request.method == 'POST':
        form = ArticleForm(request.POST)
        if form.is_valid(): # 유효성 검사
            title = form.cleaned_data.get('title')
            content = form.cleaned_data.get('content')
            article = Article(title=title, content=content)
            article.save()

        # # 1. form에 담긴 데이터를 꺼낸다
        # title = request.POST.get('title')
        # content = request.POST.get('content')

        # # 2. 데이터를 저장한다
        # article = Article()
        # article.title = title
        # article.content = content
        # article.save()
        return redirect('articles:index')
    
    else: # GET 요청일경우
        form = ArticleForm()
        context = {'form':form}
        return render(request, 'articles/new.html')