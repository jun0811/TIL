Q = []

Q.append(1)
print(Q)
Q.append(2)
print(Q)
Q.append(3)
print(Q)

print(Q.pop(0))
print(Q)
print(Q.pop(0))
print(Q)
print(Q.pop(0))
print(Q)
